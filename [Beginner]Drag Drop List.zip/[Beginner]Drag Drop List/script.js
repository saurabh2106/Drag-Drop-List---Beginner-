const sortList = document.querySelector(".sorted-list");
const items = sortList.querySelectorAll(".item");

items.forEach(item => {

    item.addEventListener("dragstart", () => {

        setTimeout(() => item.classList.add("dragging"), 0);
    });

    // Remove dragging class

    item.addEventListener("dragend", () => item.classList.remove("dragging"));
});


const initSortList = (e) => {

    e.preventDefault();

    const draggingItem = document.querySelector('.dragging');

    // get all items except currently dragging and making array of them

    let siblings = [...sortList.querySelectorAll(".item:not(.dragging)")];

    // finding siblings after which the dragging item should be placed

    let nextSibling = siblings.find(siblings => {

        return e.clientY <= siblings.offsetTop + siblings.offsetHeight / 2;
    });

    // Inserting the dragging item before the found siblings

    sortList.insertBefore(draggingItem, nextSibling);
}
sortList.addEventListener("dragover", initSortList);

sortList.addEventListener("dragenter", e => e.preventDefault());